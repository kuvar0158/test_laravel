<?php

echo trans('Admin::example.welcome');