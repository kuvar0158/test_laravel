<?php

namespace App\Modules\Admin\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Controllers\Controller;

class TestController extends Controller
{
   
   public function index(){

      print_r('hello this is test controller');

      return view('Admin::showUsers');

   }

   public function show_data(Request $request){

   	// print_r('hello ajax its working');
   	$name = $request->get('name');
   	$type = $request->get('type');
   	// print_r($type);die;
    if(!empty($name)&& !empty($type)){
   	$insertData = [

        'name' =>$name,
        'type' =>$type,
        'profile' =>''
   	 ];

   	 $test = DB::table('student')->insert($insertData);
     if($test){

   	 $res = ['success' =>1, 'msg' =>'save Data Successfully'];
   	 
   	 echo json_encode($res);
   	 exit();
     }else{

     	$res = ['success' =>0, 'msg' =>'Failed'];
     }
   	 echo json_encode($res);

    }
   }

}