<?php

namespace App\Modules\Admin\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Http\Controllers\Controller;
use Validator,Session,Redirect,Response,Config;
use Helper,Mail,URL;

class LoginController extends Controller
{
   
  public function index(){

    return view('Admin::login_form.register');
  }

  public function insert_data(Request $request){

       $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|unique:register,email',
            'contact' => 'required',
            'password' => 'required',
        ]);

       if ($validator->fails()) {
            return redirect('register')->withErrors($validator)->withInput();
        }

        else{

           $name = $request->get('name');
           $email = $request->get('email');
           $contact = $request->get('contact');
           $password = $request->get('password');
              $insertData = [

              'name' =>$name,
              'email' =>$email,
              'gender' =>'',
              'contact' =>$contact,
              'profile' =>'',
              'password' =>$password
           ];

             $test = DB::table('register')->insert($insertData);

          if($test){

              return redirect('register')->with("status", "Your data is inserted Successfully,");
          }else{

               return back()->with("status2", "Sorry Your data is not inserted Successfully!!,");
             }
        }
  }
  
   public function login(){

    return view('Admin::login_form.login');
  }
  public function login_data(Request $request){

    // print_r('expression');
      $validator = Validator::make($request->all(), [
            
            'email' => 'required|email',
            'password' => 'required',
        ]);

      if ($validator->fails()) {
            return redirect('login')->withErrors($validator)->withInput();
        }

        else{
          $email = $request->get('email');
          $password = $request->get('password');
          $result = DB::SELECT("SELECT name, email, password FROM register WHERE email='".$email."' AND password ='".$password."'");
          // print_r($result);die;
          if(!empty($result)){
            $request->session()->put('email', $email);
            print_r('yes you are login');
          }else{
            print_r('your user/password is incorrect');
          }
        }
  }

}