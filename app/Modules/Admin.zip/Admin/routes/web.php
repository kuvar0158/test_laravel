<?php

Route::group(['module' => 'Admin' , 'middleware' => ['web'], 'namespace' => 'App\Modules\Admin\Controllers'], function() {

    Route::get('/', function(){

    	// return view('Admin::showUsers');
    });

    Route::get('/','TestController@index');

    Route::post('show-data1','TestController@show_data');

    Route::get('register', 'LoginController@index');

    Route::post('Insert-data', 'LoginController@insert_data');

    Route::get('login', 'LoginController@login');

    Route::post('Login-data', 'LoginController@login_data');

});
